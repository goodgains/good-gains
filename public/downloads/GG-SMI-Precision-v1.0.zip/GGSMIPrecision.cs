#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private GGSmiPrecision[] cacheGGSmiPrecision;

		
		public GGSmiPrecision GGSmiPrecision(int lengthK, int lengthD, int lengthEMA, double overbought, double oversold, bool showMiddleLine, string licenseKey, bool useLocalLicenseServer)
		{
			return GGSmiPrecision(Input, lengthK, lengthD, lengthEMA, overbought, oversold, showMiddleLine, licenseKey, useLocalLicenseServer);
		}


		
		public GGSmiPrecision GGSmiPrecision(ISeries<double> input, int lengthK, int lengthD, int lengthEMA, double overbought, double oversold, bool showMiddleLine, string licenseKey, bool useLocalLicenseServer)
		{
			if (cacheGGSmiPrecision != null)
				for (int idx = 0; idx < cacheGGSmiPrecision.Length; idx++)
					if (cacheGGSmiPrecision[idx].LengthK == lengthK && cacheGGSmiPrecision[idx].LengthD == lengthD && cacheGGSmiPrecision[idx].LengthEMA == lengthEMA && cacheGGSmiPrecision[idx].Overbought == overbought && cacheGGSmiPrecision[idx].Oversold == oversold && cacheGGSmiPrecision[idx].ShowMiddleLine == showMiddleLine && cacheGGSmiPrecision[idx].LicenseKey == licenseKey && cacheGGSmiPrecision[idx].UseLocalLicenseServer == useLocalLicenseServer && cacheGGSmiPrecision[idx].EqualsInput(input))
						return cacheGGSmiPrecision[idx];
			return CacheIndicator<GGSmiPrecision>(new GGSmiPrecision(){ LengthK = lengthK, LengthD = lengthD, LengthEMA = lengthEMA, Overbought = overbought, Oversold = oversold, ShowMiddleLine = showMiddleLine, LicenseKey = licenseKey, UseLocalLicenseServer = useLocalLicenseServer }, input, ref cacheGGSmiPrecision);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.GGSmiPrecision GGSmiPrecision(int lengthK, int lengthD, int lengthEMA, double overbought, double oversold, bool showMiddleLine, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSmiPrecision(Input, lengthK, lengthD, lengthEMA, overbought, oversold, showMiddleLine, licenseKey, useLocalLicenseServer);
		}


		
		public Indicators.GGSmiPrecision GGSmiPrecision(ISeries<double> input , int lengthK, int lengthD, int lengthEMA, double overbought, double oversold, bool showMiddleLine, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSmiPrecision(input, lengthK, lengthD, lengthEMA, overbought, oversold, showMiddleLine, licenseKey, useLocalLicenseServer);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.GGSmiPrecision GGSmiPrecision(int lengthK, int lengthD, int lengthEMA, double overbought, double oversold, bool showMiddleLine, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSmiPrecision(Input, lengthK, lengthD, lengthEMA, overbought, oversold, showMiddleLine, licenseKey, useLocalLicenseServer);
		}


		
		public Indicators.GGSmiPrecision GGSmiPrecision(ISeries<double> input , int lengthK, int lengthD, int lengthEMA, double overbought, double oversold, bool showMiddleLine, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSmiPrecision(input, lengthK, lengthD, lengthEMA, overbought, oversold, showMiddleLine, licenseKey, useLocalLicenseServer);
		}

	}
}

#endregion
