#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private RRtradePannel[] cacheRRtradePannel;

		
		public RRtradePannel RRtradePannel(int panelLeft, int panelTop, int boxWidthPixels, string pointsPresetValues, string licenseKey, bool useLocalLicenseServer)
		{
			return RRtradePannel(Input, panelLeft, panelTop, boxWidthPixels, pointsPresetValues, licenseKey, useLocalLicenseServer);
		}


		
		public RRtradePannel RRtradePannel(ISeries<double> input, int panelLeft, int panelTop, int boxWidthPixels, string pointsPresetValues, string licenseKey, bool useLocalLicenseServer)
		{
			if (cacheRRtradePannel != null)
				for (int idx = 0; idx < cacheRRtradePannel.Length; idx++)
					if (cacheRRtradePannel[idx].PanelLeft == panelLeft && cacheRRtradePannel[idx].PanelTop == panelTop && cacheRRtradePannel[idx].BoxWidthPixels == boxWidthPixels && cacheRRtradePannel[idx].PointsPresetValues == pointsPresetValues && cacheRRtradePannel[idx].LicenseKey == licenseKey && cacheRRtradePannel[idx].UseLocalLicenseServer == useLocalLicenseServer && cacheRRtradePannel[idx].EqualsInput(input))
						return cacheRRtradePannel[idx];
			return CacheIndicator<RRtradePannel>(new RRtradePannel(){ PanelLeft = panelLeft, PanelTop = panelTop, BoxWidthPixels = boxWidthPixels, PointsPresetValues = pointsPresetValues, LicenseKey = licenseKey, UseLocalLicenseServer = useLocalLicenseServer }, input, ref cacheRRtradePannel);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.RRtradePannel RRtradePannel(int panelLeft, int panelTop, int boxWidthPixels, string pointsPresetValues, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.RRtradePannel(Input, panelLeft, panelTop, boxWidthPixels, pointsPresetValues, licenseKey, useLocalLicenseServer);
		}


		
		public Indicators.RRtradePannel RRtradePannel(ISeries<double> input , int panelLeft, int panelTop, int boxWidthPixels, string pointsPresetValues, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.RRtradePannel(input, panelLeft, panelTop, boxWidthPixels, pointsPresetValues, licenseKey, useLocalLicenseServer);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.RRtradePannel RRtradePannel(int panelLeft, int panelTop, int boxWidthPixels, string pointsPresetValues, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.RRtradePannel(Input, panelLeft, panelTop, boxWidthPixels, pointsPresetValues, licenseKey, useLocalLicenseServer);
		}


		
		public Indicators.RRtradePannel RRtradePannel(ISeries<double> input , int panelLeft, int panelTop, int boxWidthPixels, string pointsPresetValues, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.RRtradePannel(input, panelLeft, panelTop, boxWidthPixels, pointsPresetValues, licenseKey, useLocalLicenseServer);
		}

	}
}

#endregion
