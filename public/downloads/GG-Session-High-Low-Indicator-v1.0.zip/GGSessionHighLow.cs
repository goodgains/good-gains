﻿#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private GGSessionHighLow[] cacheGGSessionHighLow;
		public GGSessionHighLow GGSessionHighLow(string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle)
		{
			return GGSessionHighLow(Input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, string.Empty, true);
		}

		public GGSessionHighLow GGSessionHighLow(string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle, string licenseKey, bool useLocalLicenseServer)
		{
			return GGSessionHighLow(Input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, licenseKey, useLocalLicenseServer);
		}

		public GGSessionHighLow GGSessionHighLow(ISeries<double> input, string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle)
		{
			return GGSessionHighLow(input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, string.Empty, true);
		}

		public GGSessionHighLow GGSessionHighLow(ISeries<double> input, string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle, string licenseKey, bool useLocalLicenseServer)
		{
			if (cacheGGSessionHighLow != null)
				for (int idx = 0; idx < cacheGGSessionHighLow.Length; idx++)
					if (cacheGGSessionHighLow[idx] != null && cacheGGSessionHighLow[idx].AsiaStartTime == asiaStartTime && cacheGGSessionHighLow[idx].AsiaEndTime == asiaEndTime && cacheGGSessionHighLow[idx].LondonStartTime == londonStartTime && cacheGGSessionHighLow[idx].LondonEndTime == londonEndTime && cacheGGSessionHighLow[idx].NewYorkStartTime == newYorkStartTime && cacheGGSessionHighLow[idx].NewYorkEndTime == newYorkEndTime && cacheGGSessionHighLow[idx].LicenseKey == licenseKey && cacheGGSessionHighLow[idx].UseLocalLicenseServer == useLocalLicenseServer && cacheGGSessionHighLow[idx].ShowAsiaSessionLevels == showAsiaSessionLevels && cacheGGSessionHighLow[idx].ShowLondonSessionLevels == showLondonSessionLevels && cacheGGSessionHighLow[idx].ShowNewYorkSessionLevels == showNewYorkSessionLevels && cacheGGSessionHighLow[idx].ShowLabels == showLabels && cacheGGSessionHighLow[idx].ExtendLevelsToRight == extendLevelsToRight && cacheGGSessionHighLow[idx].LineWidth == lineWidth && cacheGGSessionHighLow[idx].LineStyle == lineStyle && cacheGGSessionHighLow[idx].EqualsInput(input))
						return cacheGGSessionHighLow[idx];
			return CacheIndicator<GGSessionHighLow>(new GGSessionHighLow(){ AsiaStartTime = asiaStartTime, AsiaEndTime = asiaEndTime, LondonStartTime = londonStartTime, LondonEndTime = londonEndTime, NewYorkStartTime = newYorkStartTime, NewYorkEndTime = newYorkEndTime, LicenseKey = licenseKey, UseLocalLicenseServer = useLocalLicenseServer, ShowAsiaSessionLevels = showAsiaSessionLevels, ShowLondonSessionLevels = showLondonSessionLevels, ShowNewYorkSessionLevels = showNewYorkSessionLevels, ShowLabels = showLabels, ExtendLevelsToRight = extendLevelsToRight, LineWidth = lineWidth, LineStyle = lineStyle }, input, ref cacheGGSessionHighLow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.GGSessionHighLow GGSessionHighLow(string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle)
		{
			return indicator.GGSessionHighLow(Input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, string.Empty, true);
		}

		public Indicators.GGSessionHighLow GGSessionHighLow(ISeries<double> input , string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle)
		{
			return indicator.GGSessionHighLow(input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, string.Empty, true);
		}

		public Indicators.GGSessionHighLow GGSessionHighLow(string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSessionHighLow(Input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, licenseKey, useLocalLicenseServer);
		}

		public Indicators.GGSessionHighLow GGSessionHighLow(ISeries<double> input , string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSessionHighLow(input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, licenseKey, useLocalLicenseServer);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.GGSessionHighLow GGSessionHighLow(string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle)
		{
			return indicator.GGSessionHighLow(Input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, string.Empty, true);
		}

		public Indicators.GGSessionHighLow GGSessionHighLow(ISeries<double> input , string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle)
		{
			return indicator.GGSessionHighLow(input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, string.Empty, true);
		}

		public Indicators.GGSessionHighLow GGSessionHighLow(string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSessionHighLow(Input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, licenseKey, useLocalLicenseServer);
		}

		public Indicators.GGSessionHighLow GGSessionHighLow(ISeries<double> input , string asiaStartTime, string asiaEndTime, string londonStartTime, string londonEndTime, string newYorkStartTime, string newYorkEndTime, bool showAsiaSessionLevels, bool showLondonSessionLevels, bool showNewYorkSessionLevels, bool showLabels, bool extendLevelsToRight, int lineWidth, DashStyleHelper lineStyle, string licenseKey, bool useLocalLicenseServer)
		{
			return indicator.GGSessionHighLow(input, asiaStartTime, asiaEndTime, londonStartTime, londonEndTime, newYorkStartTime, newYorkEndTime, showAsiaSessionLevels, showLondonSessionLevels, showNewYorkSessionLevels, showLabels, extendLevelsToRight, lineWidth, lineStyle, licenseKey, useLocalLicenseServer);
		}
	}
}

#endregion

